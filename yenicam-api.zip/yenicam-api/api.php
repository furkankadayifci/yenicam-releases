<?php
/**
 * Yeniçam Elektrik — dosya sunucusu (evraklar, fatura PDF'leri, imzalı belgeler)
 *
 * Kurulum: bu klasörü (yenicam-api) cPanel > Dosya Yöneticisi ile public_html içine yükleyin.
 * Dosyalar web kökünün DIŞINDA (public_html'in bir üstünde) "yenicam-dosyalar" klasöründe saklanır;
 * tarayıcıdan doğrudan açılamaz. Her istekte Firebase oturum anahtarı doğrulanır ve
 * yalnızca Yeniçam uygulamasında "yönetici" yetkisi olan kullanıcılar dosya yükleyip indirebilir.
 */

const PROJE = 'yenicam-elektrik';
const AZAMI_BOYUT = 25 * 1024 * 1024; // 25 MB
const KLASORLER = ['evrak', 'fatura', 'gorev', 'diger'];
const UZANTILAR = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'heic', 'doc', 'docx', 'xls', 'xlsx', 'txt'];

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Expose-Headers: Content-Disposition');
header('X-Content-Type-Options: nosniff');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

function cevap($veri, $kod = 200) { http_response_code($kod); header('Content-Type: application/json; charset=utf-8'); echo json_encode($veri, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function hata($mesaj, $kod = 400) { cevap(['ok' => false, 'hata' => $mesaj], $kod); }

/* ---------- depolama klasörü (web kökünün dışında) ---------- */
function depo() {
    static $d = null; if ($d) return $d;
    $kok = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/');
    $aday = [($kok ? dirname($kok) : dirname(__DIR__, 2)) . '/yenicam-dosyalar', __DIR__ . '/dosyalar'];
    foreach ($aday as $yol) {
        if (!is_dir($yol)) @mkdir($yol, 0750, true);
        if (is_dir($yol) && is_writable($yol)) {
            if (strpos($yol, __DIR__) === 0 && !file_exists("$yol/.htaccess")) { // yedek yer web kökündeyse erişimi kapat
                file_put_contents("$yol/.htaccess", "Require all denied\nDeny from all\n");
            }
            return $d = $yol;
        }
    }
    hata('Sunucuda dosya klasörü oluşturulamadı.', 500);
}

/* ---------- HTTP yardımcı ---------- */
function getir($url, $baslik = []) {
    $c = curl_init($url);
    curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_HTTPHEADER => $baslik, CURLOPT_FOLLOWLOCATION => true]);
    $g = curl_exec($c); $k = curl_getinfo($c, CURLINFO_HTTP_CODE); curl_close($c);
    return [$k, $g];
}

/* ---------- Firebase oturum anahtarı (ID token) doğrulama ---------- */
function b64url($s) { return base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4)); }
function sertifikalar($yenile = false) {
    $onbellek = depo() . '/.google-sertifikalar.json';
    if (!$yenile && is_file($onbellek) && time() - filemtime($onbellek) < 3600) return json_decode(file_get_contents($onbellek), true);
    [$k, $g] = getir('https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com');
    if ($k !== 200) hata('Google doğrulama anahtarlarına ulaşılamadı.', 502);
    file_put_contents($onbellek, $g);
    return json_decode($g, true);
}
function tokenDogrula($jwt) {
    $p = explode('.', $jwt); if (count($p) !== 3) hata('Geçersiz oturum.', 401);
    $H = json_decode(b64url($p[0]), true); $P = json_decode(b64url($p[1]), true);
    if (!$H || !$P || ($H['alg'] ?? '') !== 'RS256') hata('Geçersiz oturum.', 401);
    $sert = sertifikalar(); if (!isset($sert[$H['kid'] ?? ''])) $sert = sertifikalar(true);
    $pem = $sert[$H['kid'] ?? ''] ?? null; if (!$pem) hata('Geçersiz oturum.', 401);
    if (openssl_verify("$p[0].$p[1]", b64url($p[2]), $pem, OPENSSL_ALGO_SHA256) !== 1) hata('Geçersiz oturum.', 401);
    $simdi = time();
    if (($P['aud'] ?? '') !== PROJE || ($P['iss'] ?? '') !== 'https://securetoken.google.com/' . PROJE) hata('Geçersiz oturum.', 401);
    if (($P['exp'] ?? 0) < $simdi - 60 || ($P['iat'] ?? 0) > $simdi + 300 || empty($P['sub'])) hata('Oturum süresi dolmuş. Uygulamada yeniden giriş yapın.', 401);
    return $P;
}
function yoneticiMi($uid, $token) {
    $url = 'https://firestore.googleapis.com/v1/projects/' . PROJE . '/databases/(default)/documents/kullanicilar/' . rawurlencode($uid);
    [$k, $g] = getir($url, ['Authorization: Bearer ' . $token]);
    if ($k !== 200) return false;
    $f = (json_decode($g, true)['fields'] ?? []);
    return ($f['rol']['stringValue'] ?? '') === 'yonetici' && empty($f['pasif']['booleanValue']);
}
function yetkiliKullanici() {
    $b = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$b && function_exists('apache_request_headers')) { $h = array_change_key_case(apache_request_headers()); $b = $h['authorization'] ?? ''; }
    if (!$b && isset($_POST['token'])) $b = 'Bearer ' . $_POST['token']; // bazı sunucular Authorization başlığını iletmez
    if (!$b && isset($_GET['token'])) $b = 'Bearer ' . $_GET['token'];
    if (!preg_match('/^Bearer\s+(\S+)$/', $b, $m)) hata('Oturum bilgisi yok.', 401);
    $P = tokenDogrula($m[1]);
    if (!yoneticiMi($P['sub'], $m[1])) hata('Bu işlem için yönetici yetkisi gerekiyor.', 403);
    return $P;
}

/* ---------- yol güvenliği ---------- */
function guvenliYol($yol) {
    if (!preg_match('#^(' . implode('|', KLASORLER) . ')/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9._-]{1,120}$#', $yol) || strpos($yol, '..') !== false) hata('Geçersiz dosya yolu.');
    return depo() . '/' . $yol;
}
function boyutOku($s) { $s = trim($s); $n = (float)$s; $b = strtolower(substr($s, -1)); return (int)($b === 'g' ? $n * 1073741824 : ($b === 'm' ? $n * 1048576 : ($b === 'k' ? $n * 1024 : $n))); }

/* ---------- işlemler ---------- */
$islem = $_GET['islem'] ?? '';

if ($islem === 'test') {
    $d = depo();
    cevap(['ok' => true, 'uygulama' => 'yenicam-api', 'php' => PHP_VERSION, 'curl' => function_exists('curl_init'), 'openssl' => function_exists('openssl_verify'),
        'depoYazilabilir' => is_writable($d), 'depoWebDisinda' => strpos($d, __DIR__) !== 0,
        'azamiYukleme' => min(boyutOku(ini_get('upload_max_filesize')), boyutOku(ini_get('post_max_size')), AZAMI_BOYUT)]);
}

if ($islem === 'yukle') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') hata('POST gerekli.', 405);
    $k = yetkiliKullanici();
    $klasor = $_POST['klasor'] ?? ''; $kayit = $_POST['kayit'] ?? '';
    if (!in_array($klasor, KLASORLER, true) || !preg_match('/^[A-Za-z0-9_-]{1,64}$/', $kayit)) hata('Geçersiz klasör.');
    $f = $_FILES['dosya'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK) hata($f && in_array($f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE]) ? 'Dosya sunucunun izin verdiği boyuttan büyük.' : 'Dosya alınamadı.');
    if ($f['size'] > AZAMI_BOYUT) hata('Dosya 25 MB’den büyük olamaz.');
    $uz = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($uz, UZANTILAR, true)) hata('Bu dosya türü desteklenmiyor: .' . $uz);
    $ad = date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $uz;
    $hedefKlasor = depo() . "/$klasor/$kayit";
    if (!is_dir($hedefKlasor) && !mkdir($hedefKlasor, 0750, true)) hata('Klasör oluşturulamadı.', 500);
    if (!move_uploaded_file($f['tmp_name'], "$hedefKlasor/$ad")) hata('Dosya kaydedilemedi.', 500);
    cevap(['ok' => true, 'yol' => "$klasor/$kayit/$ad", 'ad' => $f['name'], 'boyut' => $f['size'], 'tur' => $uz, 'yukleyen' => $k['sub']]);
}

if ($islem === 'indir') {
    yetkiliKullanici();
    $tam = guvenliYol($_GET['yol'] ?? '');
    if (!is_file($tam)) hata('Dosya bulunamadı.', 404);
    $tur = ['pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'][strtolower(pathinfo($tam, PATHINFO_EXTENSION))] ?? 'application/octet-stream';
    $ad = preg_replace('/[^\w.\- ]/u', '_', $_GET['ad'] ?? basename($tam));
    header('Content-Type: ' . $tur);
    header('Content-Length: ' . filesize($tam));
    header('Content-Disposition: attachment; filename="' . $ad . '"');
    readfile($tam); exit;
}

if ($islem === 'sil') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') hata('POST gerekli.', 405);
    yetkiliKullanici();
    $tam = guvenliYol($_POST['yol'] ?? '');
    if (is_file($tam)) unlink($tam);
    cevap(['ok' => true]);
}

hata('Bilinmeyen işlem.', 404);
